146: Misplaced alignment tab character &. تعالی و برتری جهانی &
148: Misplaced \noalign. \bottomrule
149: Misplaced \crcr. \end{tabular}
149: Too many }'s. \end{tabular}
149: Too many }'s. \end{tabular}
149: Too many }'s. \end{tabular}
149: Too many }'s. \end{tabular}
149: Missing $ inserted. \end{tabular}
149: Too many }'s. \end{tabular}
149: \begin{document} ended by \end{tabular}. \end{tabular}
149: Extra \endgroup. \end{tabular}
150: Too many }'s. \end{table}
150: Extra \endgroup. \end{table}
150: Too many }'s. \end{table}
150: \begin{document} ended by \end{table}. \end{table}
150: Extra \endgroup. \end{table}
156: Package xcolor Error: Undefined color `rougelight'. ...le={\textbf{بحرانی: ۱۰۰ روز سرنوشت‌ساز}}]
260: Misplaced \crcr. \end{tabular}
260: Extra }, or forgotten \endgroup. \end{tabular}
260: Extra }, or forgotten \endgroup. \end{tabular}
260: Extra }, or forgotten \endgroup. \end{tabular}
260: Extra }, or forgotten \endgroup. \end{tabular}
260: Missing $ inserted. \end{tabular}
260: Extra }, or forgotten \endgroup. \end{tabular}
260: \begin{tikzpicture} on input line 198 ended by \end{tabular}. \end{tabular}
261: Extra }, or forgotten \endgroup. }
267: Package xcolor Error: Undefined color `vertlight'. };
267: Package pgf Error: Unsupported color model `'. Sorry. };
267: Package xcolor Error: Undefined color `vertlight'. };
267: Missing \endcsname inserted. };
145: Incomplete \ifx; all text was ignored after line 267. ^^I\input{chapters/ch00-executive}
: Incomplete \ifx; all text was ignored after line 267.
27: Font shape `TU/Vazirmatn(2)/m/it' undefined(Font) using `TU/Vazirmatn(2)/m/n' instead
66: Overfull \hbox (95.03789pt too wide) in paragraph
: Underfull \vbox (badness 10000) has occurred while \output is active []
146: Underfull \hbox (badness 10000) in paragraph
: Underfull \vbox (badness 2012) has occurred while \output is active []